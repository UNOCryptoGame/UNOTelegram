export const cardColorsCode = {
  blue: "#5555ff",
  green: "#55aa55",
  red: "#ff5555",
  yellow: "#ffaa00"
}
