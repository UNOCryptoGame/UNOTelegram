import Loading from "@components/Loading"

export default Loading
