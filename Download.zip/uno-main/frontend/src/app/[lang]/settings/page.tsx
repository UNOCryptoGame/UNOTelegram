"use client"

import useBackButton from "@hooks/useBackButton"

export default function Settings() {
  useBackButton()

  return <div></div>
}
