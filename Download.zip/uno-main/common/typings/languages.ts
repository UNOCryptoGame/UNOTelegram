export const languages = [
  "en",
  "ru",
  "de",
  "es",
  "hi",
  "it",
  "pt",
  "tr",
  "uz",
  "zh",
  "uk"
]
export const defaultLocale = "ru"
